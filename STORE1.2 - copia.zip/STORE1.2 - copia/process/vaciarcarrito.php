<?php
session_start();
unset($_SESSION['carro']);
?>
<script>
    window.location = "../carrito.php";
</script>
