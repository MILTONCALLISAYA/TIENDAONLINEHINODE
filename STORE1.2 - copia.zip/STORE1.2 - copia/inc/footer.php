<div class="ResForm"></div>
<div class="ResbeforeSend"></div>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h4 class="text-footer">Contactanos</h4>
                <a href="https://www.facebook.com/calliMcM?mibextid=ZbWKwL" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true">&nbsp; Facebook </i> 
                </a><br>
                <a href="https://wa.me/message/F6KJXKFPQZALO1" target="_blank">
                    <i class="fa fa-whatsapp" aria-hidden="true">&nbsp; Whatssap </i>
                </a><br>
                <a href="https://www.tiktok.com/@noemil.shop?_r=1&_d=ea5d96lhd5mf1g&sec_uid=MS4wLjABAAAAjYuedM4s5nWtlj0UWB1oqKeRmt-jssdQqU5yJODKmv_vwPnLLT5-DRPDCmynCw9G&share_author_id=7122623126587999237&sharer_language=es&source=h5_m&u_code=dhf93d9mggccm6&timestamp=1714426578&user_id=6939692760996676613&sec_user_id=MS4wLjABAAAAyldn4FaoYwU0VDOzzAw6sjsSLnieTKFXA-1YrG2KoIJsntOpoa3rpGBafo-x3dek&utm_source=copy&utm_campaign=client_share&utm_medium=android&share_iid=7363246677157791494&share_link_id=c72560bf-5864-4cfe-8e34-68ed5cf5e62b&share_app_id=1233&ugbiz_name=ACCOUNT&ug_btm=b7360%2Cb5836&social_share_type=5&enable_checksum=1" target="_blank">
                    <i class="fa fa-youtube-play" aria-hidden="true">&nbsp; Tik Tok </i>
                </a><br>
                <a href="https://www.instagram.com/noemil.shop?igsh=MTZ3OGJsemFvcnd4Zw==" target="_blank">
                    <i class="fa fa-instagram" aria-hidden="true">&nbsp; Instagram </i>
                </a><br>
                <a href="https://maps.app.goo.gl/iGmDuWimVQUKxE7F9" target="_blank">
                    <i class="fa fa-map-marker" aria-hidden="true">&nbsp; Encuentranos </i>
                </a>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer">Porque elegirnos</h4>
                <p> 
                    Contamos con los mejores productos.</br>
                    la mejor empresa de brasil.</br>
                    Con los mejores servicios.</br>
                    
                </p>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer" >Direccion</h4>
                <p style="color: #FFF">El Alto</p>
                <p style="color: #FFF">La Paz-BOLIVIA</p>
                <p style="font-size:20px" aria-hidden="true"> +591 – 73523942 / +591 – 63062712</p>
                <p class="fa fa-mobile" style="font-size:20px"  aria-hidden="true">  73523942 / 63062712</p> <a href="#" target="_blank" style="color: #5bc0de">envianos_un_mensaje</a></br>
                E-mail: <a href="#" target="_blank" style="color: #5bc0de"> &nbsp; mamanicallisaya10jr@gmail.com</a>
            </div>
        </div>
    </div>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo text-footer">MCM &copy; 2022</h5>
</footer>
